import "./FooterStyles.css";
import React from 'react';
import { FaHome, FaLinkedin, FaMailBulk, FaPhone, FaTwitter, FaFacebook } from "react-icons/fa";

const Footer = () =>{
    return (
<div className="footer">
    <div className="footer-container">
        <div className="left">
        <div className="location">
            <FaHome size={20} style={{color: "white", marginRight: "2rem"}}/>
            <div>
                <p>Sundhara, Lalitpur </p>
                <p>Nepal.</p>
            </div>
        </div>
        <div className="phone">
            <h4>
            <FaPhone size={20} style={{color:"white", marginRight:"2rem"}}/>
            +977-9803436194
            </h4>
        </div>
        <div className="email">
            <h4>
                
            <FaMailBulk size={20} style={{color: "white", marginRight: "2rem" }}/>
            rubinshrestha323@gmail.com
            </h4>
            
            
        </div>
        </div>
        <div className="right"> 
        <h4> About Myself</h4>
        <p> This is Rubin Shrestha. I am a student of computer application and I enjoy discussing new projects and design challenges.</p>
        <div className="social">
        <FaFacebook size={30} style={{color: "white", marginRight: "1rem" }}/>
        <FaTwitter size={30} style={{color: "white", marginRight: "1rem" }}/>
        <FaLinkedin size={30} style={{color: "white", marginRight: "1rem" }}/>
        </div>
        
        
        
        
        
        
        </div>

    </div>

</div>
    )
}

export default Footer;