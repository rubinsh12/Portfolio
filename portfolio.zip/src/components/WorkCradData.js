import pro1 from "../assets/project1.png";


const ProjectCardData =[
    {
        imgsrc: pro1,
        title:"Ecommerce Website Design ",
        text:"Description"

    },
    
];
export default ProjectCardData; 